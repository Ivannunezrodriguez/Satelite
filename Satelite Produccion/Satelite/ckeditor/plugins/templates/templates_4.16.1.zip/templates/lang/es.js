/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'es', {
	button: 'Plantillas',
	emptyListMsg: '(No hay plantillas definidas)',
	insertOption: 'Reemplazar el contenido actual',
	options: 'Opciones de plantillas',
	selectPromptMsg: 'Por favor selecciona la plantilla a abrir en el editor<br>(el contenido actual se perderá):',
	title: 'Contenido de Plantillas'
} );
