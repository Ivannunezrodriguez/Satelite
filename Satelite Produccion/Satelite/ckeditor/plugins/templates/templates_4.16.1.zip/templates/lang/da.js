/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'da', {
	button: 'Skabeloner',
	emptyListMsg: '(Der er ikke defineret nogen skabelon)',
	insertOption: 'Erstat det faktiske indhold',
	options: 'Skabelon muligheder',
	selectPromptMsg: 'Vælg den skabelon, som skal åbnes i editoren (nuværende indhold vil blive overskrevet):',
	title: 'Indholdsskabeloner'
} );
