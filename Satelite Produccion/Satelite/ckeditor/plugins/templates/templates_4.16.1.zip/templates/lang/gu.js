/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'gu', {
	button: 'ટેમ્પ્લેટ',
	emptyListMsg: '(કોઈ ટેમ્પ્લેટ ડિફાઇન નથી)',
	insertOption: 'મૂળ શબ્દને બદલો',
	options: 'ટેમ્પ્લેટના વિકલ્પો',
	selectPromptMsg: 'એડિટરમાં ઓપન કરવા ટેમ્પ્લેટ પસંદ કરો (વર્તમાન કન્ટેન્ટ સેવ નહીં થાય):',
	title: 'કન્ટેન્ટ ટેમ્પ્લેટ'
} );
