/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'ka', {
	button: 'თარგები',
	emptyListMsg: '(თარგი არაა განსაზღვრული)',
	insertOption: 'მიმდინარე შეგთავსის შეცვლა',
	options: 'თარგების პარამეტრები',
	selectPromptMsg: 'აირჩიეთ თარგი რედაქტორისთვის',
	title: 'თარგები'
} );
