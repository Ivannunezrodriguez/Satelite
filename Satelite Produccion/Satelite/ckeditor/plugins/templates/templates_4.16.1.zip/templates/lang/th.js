/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'th', {
	button: 'เทมเพลต',
	emptyListMsg: '(ยังไม่มีการกำหนดเทมเพลต)',
	insertOption: 'แทนที่เนื้อหาเว็บไซต์ที่เลือก',
	options: 'ตัวเลือกเกี่ยวกับเทมเพลท',
	selectPromptMsg: 'กรุณาเลือก เทมเพลต เพื่อนำไปแก้ไขในอีดิตเตอร์<br />(เนื้อหาส่วนนี้จะหายไป):',
	title: 'เทมเพลตของส่วนเนื้อหาเว็บไซต์'
} );
