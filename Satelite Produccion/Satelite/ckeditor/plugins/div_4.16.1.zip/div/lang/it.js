/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'it', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Titolo Avviso',
	cssClassInputLabel: 'Classi di stile',
	edit: 'Modifica DIV',
	inlineStyleInputLabel: 'Stile Inline',
	langDirLTRLabel: 'Da sinistra a destra (LTR)',
	langDirLabel: 'Direzione di scrittura',
	langDirRTLLabel: 'Da destra a sinistra (RTL)',
	languageCodeInputLabel: 'Codice lingua',
	remove: 'Rimuovi DIV',
	styleSelectLabel: 'Stile',
	title: 'Crea DIV contenitore',
	toolbar: 'Crea DIV contenitore'
} );
