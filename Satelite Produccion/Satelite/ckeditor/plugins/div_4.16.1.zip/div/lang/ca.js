/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'ca', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Títol de guia',
	cssClassInputLabel: 'Classes de la fulla d\'estils',
	edit: 'Edita la Capa',
	inlineStyleInputLabel: 'Estil en línia',
	langDirLTRLabel: 'D\'esquerra a dreta (LTR)',
	langDirLabel: 'Direcció de l\'idioma',
	langDirRTLLabel: 'De dreta a esquerra (RTL)',
	languageCodeInputLabel: ' Codi d\'idioma',
	remove: 'Elimina la Capa',
	styleSelectLabel: 'Estil',
	title: 'Crea una Capa Contenidora',
	toolbar: 'Crea una Capa Contenidora'
} );
