/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'et', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'Soovitatav pealkiri',
	cssClassInputLabel: 'Stiililehe klassid',
	edit: 'Muuda Div',
	inlineStyleInputLabel: 'Reasisene stiil',
	langDirLTRLabel: 'Vasakult paremale (LTR)',
	langDirLabel: 'Keele suund',
	langDirRTLLabel: 'Paremalt vasakule (RTL)',
	languageCodeInputLabel: ' Keelekood',
	remove: 'Eemalda Div',
	styleSelectLabel: 'Stiil',
	title: 'Div-konteineri loomine',
	toolbar: 'Div-konteineri loomine'
} );
