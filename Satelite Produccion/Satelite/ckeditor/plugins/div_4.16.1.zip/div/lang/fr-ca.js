/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'fr-ca', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'Titre',
	cssClassInputLabel: 'Classes CSS',
	edit: 'Modifier le DIV',
	inlineStyleInputLabel: 'Style en ligne',
	langDirLTRLabel: 'De gauche à droite (LTR)',
	langDirLabel: 'Sens d\'écriture',
	langDirRTLLabel: 'De droite à gauche (RTL)',
	languageCodeInputLabel: 'Code de langue',
	remove: 'Supprimer le DIV',
	styleSelectLabel: 'Style',
	title: 'Créer un DIV',
	toolbar: 'Créer un DIV'
} );
